import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Maximize2, RotateCw, Undo2, Eraser, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SIG_COLOR, SIG_H, SIG_W, drawStrokes, hasInk, strokesToBlob, toLogical, type Stroke } from "@/lib/carte/signature";

interface Props {
  title: string;
  hint?: string;
  saveLabel?: string;
  onSave: (png: Blob) => void | Promise<void>;
  onClose: () => void;
  onSkip?: () => void;
}

/** Rectangle blanc pour signer au doigt ou à la souris (tracé bleu). « Plein écran » + « Tourner » : le rectangle
    occupe tout l'écran du téléphone, même tenu en hauteur. */
export default function SignaturePad({ title, hint, saveLabel = "Valider la signature", onSave, onClose, onSkip }: Props) {
  const [big, setBig] = useState(false);
  const [flip, setFlip] = useState(false);
  const [vp, setVp] = useState({ w: window.innerWidth, h: window.innerHeight });
  // Rectangle tourné de 90° seulement si l'écran est tenu en hauteur (déduit de la taille réelle de l'écran, jamais figé).
  const rot = big && ((vp.h > vp.w) !== flip);
  const lastPortrait = useRef(vp.h > vp.w);
  const [strokes, setStrokes] = useState<Stroke[]>([]);
  const [saving, setSaving] = useState(false);
  const cv = useRef<HTMLCanvasElement>(null);
  const area = useRef<HTMLDivElement>(null);
  const cur = useRef<Stroke | null>(null);
  const [box, setBox] = useState({ w: 300, h: 150 });

  useEffect(() => {
    const f = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", f); window.addEventListener("orientationchange", f);
    return () => { window.removeEventListener("resize", f); window.removeEventListener("orientationchange", f); };
  }, []);
  // Si l'écran pivote (téléphone tourné), on repart d'un affichage normal.
  useEffect(() => { const p = vp.h > vp.w; if (p !== lastPortrait.current) { lastPortrait.current = p; setFlip(false); } }, [vp]);

  // Taille du rectangle : toujours 2:1, le plus grand possible dans la zone disponible
  useLayoutEffect(() => {
    const el = area.current; if (!el) return;
    const w = el.clientWidth, h = el.clientHeight;
    const k = Math.min(w / SIG_W, h / SIG_H);
    setBox({ w: Math.max(100, Math.floor(SIG_W * k)), h: Math.max(50, Math.floor(SIG_H * k)) });
  }, [big, rot, vp]);

  const redraw = (list: Stroke[]) => {
    const c = cv.current; if (!c) return;
    const dpr = Math.min(3, window.devicePixelRatio || 1);
    const scale = (box.w * dpr) / SIG_W;
    c.width = Math.round(box.w * dpr); c.height = Math.round(box.h * dpr);
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, c.width, c.height);
    drawStrokes(ctx, list, scale);
  };
  useLayoutEffect(() => redraw(strokes), [box, strokes]); // eslint-disable-line react-hooks/exhaustive-deps

  const pt = (e: React.PointerEvent) => toLogical(e.clientX, e.clientY, cv.current!.getBoundingClientRect(), rot);
  const down = (e: React.PointerEvent) => {
    e.preventDefault(); (e.target as Element).setPointerCapture?.(e.pointerId);
    const first: Stroke = [pt(e)];
    cur.current = first; setStrokes(s => [...s, first]);
  };
  const move = (e: React.PointerEvent) => {
    if (!cur.current) return;
    e.preventDefault();
    const evs = (e.nativeEvent as PointerEvent).getCoalescedEvents?.() ?? [];
    const rect = cv.current!.getBoundingClientRect();
    const stroke = cur.current;
    (evs.length ? evs : [e.nativeEvent as PointerEvent]).forEach(ev => stroke.push(toLogical(ev.clientX, ev.clientY, rect, rot)));
    // copie figée : React exécute cette fonction plus tard, quand le doigt est peut-être déjà levé (cur.current vaudrait alors null)
    const snapshot = [...stroke];
    setStrokes(s => [...s.slice(0, -1), snapshot]);
  };
  const up = () => { cur.current = null; };

  const enterBig = async () => {
    setFlip(false); setBig(true);
    try { await document.documentElement.requestFullscreen?.(); } catch { /* le bouton « Tourner » prend le relais */ }
  };
  const leaveBig = () => { setBig(false); setFlip(false); try { if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); } catch { /* */ } };
  const close = () => { leaveBig(); onClose(); };

  const save = async () => {
    if (saving) return;
    setSaving(true);
    try {
      const png = await strokesToBlob(strokes);
      if (!png) return;
      leaveBig(); // on quitte le plein écran AVANT d'enregistrer : le composant peut disparaître juste après
      await onSave(png);
    } catch (e) { console.error("signature", e); } finally { setSaving(false); }
  };

  const bar = (
    <div className="flex flex-wrap items-center gap-2 p-2 bg-background border-b">
      <div className="flex-1 min-w-0"><p className="font-semibold truncate">{title}</p>{hint && <p className="text-xs text-muted-foreground truncate">{hint}</p>}</div>
      {!big ? <Button size="sm" variant="outline" onClick={enterBig}><Maximize2 className="h-4 w-4 mr-1" />Plein écran</Button>
        : <Button size="sm" variant="outline" onClick={() => setFlip(f => !f)}><RotateCw className="h-4 w-4 mr-1" />Tourner</Button>}
      {big && <Button size="sm" variant="ghost" onClick={leaveBig}>Réduire</Button>}
      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={close} aria-label="Fermer"><X className="h-4 w-4" /></Button>
    </div>
  );
  const pad = (
    <div ref={area} className="flex-1 min-h-0 flex items-center justify-center p-2 bg-muted/40">
      <canvas ref={cv} style={{ width: box.w, height: box.h, touchAction: "none", background: "#fff", borderRadius: 8, boxShadow: "0 0 0 2px #cbd5e1", cursor: "crosshair" }}
        onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up} />
    </div>
  );
  const actions = (
    <div className="flex flex-wrap items-center gap-2 p-2 bg-background border-t">
      <Button size="sm" variant="outline" disabled={!strokes.length} onClick={() => setStrokes(s => s.slice(0, -1))}><Undo2 className="h-4 w-4 mr-1" />Annuler le trait</Button>
      <Button size="sm" variant="outline" disabled={!strokes.length} onClick={() => setStrokes([])}><Eraser className="h-4 w-4 mr-1" />Effacer</Button>
      <span className="flex-1" />
      {onSkip && <Button size="sm" variant="ghost" onClick={() => { leaveBig(); onSkip(); }}>Passer</Button>}
      <Button size="sm" disabled={!hasInk(strokes) || saving} onClick={save} style={{ background: SIG_COLOR }}><Check className="h-4 w-4 mr-1" />{saveLabel}</Button>
    </div>
  );

  if (big) {
    const style: React.CSSProperties = rot
      ? { position: "fixed", top: 0, left: vp.w, width: vp.h, height: vp.w, transform: "rotate(90deg)", transformOrigin: "0 0" }
      : { position: "fixed", top: 0, left: 0, width: vp.w, height: vp.h };
    return <div className="z-[100] fixed inset-0 bg-background overflow-hidden"><div className="flex flex-col" style={style}>{bar}{pad}{actions}</div></div>;
  }
  return (
    <div className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-2 sm:p-4" onClick={close}>
      <div className="bg-background rounded-lg shadow-xl w-full max-w-2xl flex flex-col overflow-hidden" style={{ maxHeight: "92vh" }} onClick={e => e.stopPropagation()}>
        {bar}
        <div style={{ height: Math.min(360, Math.max(200, Math.round((Math.min(vp.w, 672) - 32) / 2) + 30)) }} className="flex flex-col">{pad}</div>
        {actions}
      </div>
    </div>
  );
}
